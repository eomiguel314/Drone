//
// File: flightController_data.cpp
//
// Code generated for Simulink model 'flightController'.
//
// Model version                  : 1.125
// Simulink Coder version         : 8.14 (R2018a) 06-Feb-2018
// C/C++ source code generated on : Sat Jan 17 18:32:33 2026
//
// Target selection: ert.tlc
// Embedded hardware selection: Custom Processor->Custom
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
// Validation result: Not run
//
#include "flightController.h"

// Constant parameters (default storage)
const ConstP rtConstP = {
  // Computed Parameter: TorqueTotalThrustToThrustPerMotor_Value
  //  Referenced by: '<S3>/TorqueTotalThrustToThrustPerMotor'

  { 0.25F, 0.25F, 0.25F, 0.25F, 103.573624F, -103.573624F, 103.573624F,
    -103.573624F, -5.66592F, -5.66592F, 5.66592F, 5.66592F, -5.66592F, 5.66592F,
    5.66592F, -5.66592F },

  // Computed Parameter: MotorDirections_Gain
  //  Referenced by: '<S7>/MotorDirections'

  { 1.0F, -1.0F, 1.0F, -1.0F }
};

//
// File trailer for generated code.
//
// [EOF]
//
